// ---------- menu lateral (sidebar) ----------
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('sidebarOverlay');
const menuBtn = document.getElementById('menuBtn');
const closeBtn = document.getElementById('sidebarClose');

function openSidebar(){
  sidebar.classList.add('is-open');
  overlay.classList.add('is-visible');
  document.body.classList.add('no-scroll');
  menuBtn && menuBtn.setAttribute('aria-expanded', 'true');
}
function closeSidebar(){
  sidebar.classList.remove('is-open');
  overlay.classList.remove('is-visible');
  document.body.classList.remove('no-scroll');
  menuBtn && menuBtn.setAttribute('aria-expanded', 'false');
}
if (menuBtn) menuBtn.addEventListener('click', openSidebar);
if (closeBtn) closeBtn.addEventListener('click', closeSidebar);
if (overlay) overlay.addEventListener('click', closeSidebar);
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeSidebar(); });
if (sidebar){
  sidebar.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
    if (window.innerWidth < 1024) closeSidebar();
  }));
}

// ---------- barra de progresso de rolagem ----------
const progressBar = document.getElementById('progressBar');
function updateProgress(){
  if (!progressBar) return;
  const h = document.documentElement;
  const scrolled = (h.scrollTop) / (h.scrollHeight - h.clientHeight) * 100;
  progressBar.style.width = (isFinite(scrolled) ? scrolled : 0) + '%';
}
document.addEventListener('scroll', updateProgress, { passive:true });
updateProgress();

// ---------- revelar ao rolar ----------
const revealEls = document.querySelectorAll('.reveal');
const io = new IntersectionObserver((entries) => {
  entries.forEach(e => { if (e.isIntersecting){ e.target.classList.add('is-visible'); io.unobserve(e.target); } });
}, { threshold:.15, rootMargin:'0px 0px -8% 0px' });
revealEls.forEach(el => io.observe(el));

// ---------- efeito de luz quente seguindo o cursor sobre a foto do banner (só existe no Início) ----------
const heroSection = document.getElementById('inicio');
const heroGlow = document.getElementById('heroGlow');
if (heroSection && heroGlow){
  heroSection.addEventListener('mousemove', (e) => {
    const rect = heroSection.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    heroGlow.style.setProperty('--mx', x + '%');
    heroGlow.style.setProperty('--my', y + '%');
  });
}
